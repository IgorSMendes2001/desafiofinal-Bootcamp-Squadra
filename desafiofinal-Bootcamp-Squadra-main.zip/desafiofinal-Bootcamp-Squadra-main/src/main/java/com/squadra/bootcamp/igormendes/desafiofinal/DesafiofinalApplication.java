package com.squadra.bootcamp.igormendes.desafiofinal;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DesafiofinalApplication {

	public static void main(String[] args) {
		SpringApplication.run(DesafiofinalApplication.class, args);
	}

}
  