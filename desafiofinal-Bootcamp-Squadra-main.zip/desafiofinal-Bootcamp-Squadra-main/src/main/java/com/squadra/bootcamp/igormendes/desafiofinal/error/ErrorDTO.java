package com.squadra.bootcamp.igormendes.desafiofinal.error;

import lombok.Data;

@Data
public class ErrorDTO {
    private String key;
    private String message;

    public ErrorDTO() {
    }

    public ErrorDTO(String key, String message) {
        this.key = key;
        this.message = message;
    }
}
