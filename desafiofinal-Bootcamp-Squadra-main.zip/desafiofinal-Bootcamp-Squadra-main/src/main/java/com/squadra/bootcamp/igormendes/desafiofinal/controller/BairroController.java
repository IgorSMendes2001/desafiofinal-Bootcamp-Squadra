package com.squadra.bootcamp.igormendes.desafiofinal.controller;

import com.squadra.bootcamp.igormendes.desafiofinal.model.BairroDTO;
import com.squadra.bootcamp.igormendes.desafiofinal.service.BairroService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping({"/bairro"})
public class BairroController {
    @Autowired
    private BairroService bairroService;

    @GetMapping
    public List<BairroDTO> findAll() {
        List<BairroDTO> listBairroDTO = bairroService.findAll();
        return listBairroDTO;
    }
    @GetMapping(params = "codigoBairro")

    public ResponseEntity<BairroDTO> findById(@RequestParam  Long codigoBairro) {
        BairroDTO listBairroDTO = bairroService.findById(codigoBairro);
        return ResponseEntity.ok(listBairroDTO);
    }
    @GetMapping(params = "codigoMunicipio")

    public ResponseEntity<BairroDTO> findByCodigoMunicipio(@RequestParam  Long codigoMunicipio) {
        BairroDTO listBairroDTO = bairroService.findByCodigoMunicipio(codigoMunicipio);
        return ResponseEntity.ok(listBairroDTO);
    }

    @PostMapping
    public ResponseEntity<?> save(@RequestBody BairroDTO bairroDTO) {

        bairroDTO = bairroService.save(bairroDTO);
        if (bairroDTO.getCodigoBairro() == null) {
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body("Mensagem:Não foi possível cadastrar bairro no banco de dados! " +" "+ "Status:400");
        }
        return ResponseEntity.status(HttpStatus.CREATED).body(bairroDTO);
    }



    @PutMapping
    public ResponseEntity<?> update(@RequestBody BairroDTO bairroDTO) {

        bairroDTO = bairroService.update(bairroDTO);

        if (bairroDTO.getCodigoBairro() == null) {
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body("Mensagem:Não foi possível atualizar bairro no banco de dados!"+" "+ "Status:400");
        }
        return ResponseEntity.status(HttpStatus.CREATED).body(bairroDTO);
    }

}