package com.squadra.bootcamp.igormendes.desafiofinal.model;

import lombok.Data;

import java.util.List;

import javax.persistence.*;

import org.hibernate.validator.constraints.UniqueElements;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonManagedReference;
@Data
@Entity
@Table(name="tb_bairro")
public class Bairro{
    @Id
    @GeneratedValue(generator= "bairro_sequence",strategy = GenerationType.SEQUENCE)
    @SequenceGenerator(name="bairro_sequence",sequenceName = "bair_seq" )
    @Column(name = "CODIGO_BAIRRO")
    private Long codigoBairro;
    @ManyToOne
    @JoinColumn(name = "CODIGO_MUNICIPIO")
    private Municipio codigoMunicipio;
    @JsonManagedReference
    @JsonIgnore
    @OneToMany(cascade = CascadeType.ALL)
    private List<Municipio>municipios;
    @Column(name = "NOME",unique = true)
    private String nome;
    @Column(name = "STATUS")
    private Integer status;
    public Bairro(){

    }


}
