package com.squadra.bootcamp.igormendes.desafiofinal.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.squadra.bootcamp.igormendes.desafiofinal.model.EnderecoDTO;
import com.squadra.bootcamp.igormendes.desafiofinal.model.PessoaDTO;
import com.squadra.bootcamp.igormendes.desafiofinal.service.EnderecoService;
import com.squadra.bootcamp.igormendes.desafiofinal.service.PessoaService;

@RestController
@RequestMapping({"/pessoa"})
public class PessoaController {
    @Autowired
    private PessoaService pessoaService;
	@Autowired
	private EnderecoService enderecoService;

    @GetMapping("/pessoa")
    public List<PessoaDTO> findAll() {
        List<PessoaDTO> listPessoaDTO = pessoaService.findAll();
        return listPessoaDTO;
    }

    @GetMapping(params ="codigoPessoa")
    public ResponseEntity<PessoaDTO> findById(@RequestParam () Long codigoPessoa) {
        PessoaDTO pessoaDTO = pessoaService.findByid(codigoPessoa);
        return ResponseEntity.ok(pessoaDTO);
    }
    @GetMapping(params = "login")
    public ResponseEntity<PessoaDTO> findByNome(@RequestParam  String login) {
            PessoaDTO pessoaDTO = pessoaService.findByLogin(login);
            return ResponseEntity.ok(pessoaDTO);
        }
    
    @PostMapping
    public ResponseEntity<?> save(@RequestBody PessoaDTO pessoaDTO) {

        pessoaDTO = pessoaService.save(pessoaDTO);
        if (pessoaDTO.getCodigoPessoa() == null) {
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body("Mensagem:Não foi possível cadastrar Pessoa no banco de dados!"+" "+ "Status:400");
        }
        return ResponseEntity.status(HttpStatus.OK).body(pessoaDTO);
    }

    @GetMapping(params = "status")
    public  List<PessoaDTO> findByStatus(@RequestParam  Integer status) {
            List<PessoaDTO> listaPessoaDTO = pessoaService.findByStatus(status);
            return listaPessoaDTO;
        }

    @PutMapping
    public ResponseEntity<?> update(@RequestBody PessoaDTO pessoaDTO) {

        pessoaDTO = pessoaService.update(pessoaDTO);

        if (pessoaDTO.getCodigoPessoa() == null) {
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body("Mensagem:Não foi possível alterar Pessoa no banco de dados!"+" "+ "Status:400");
        }
        return ResponseEntity.status(HttpStatus.OK).body(pessoaDTO);
    }
 	@GetMapping(params = "enderecos")
    public List<EnderecoDTO> findByEndereco() {
        List<EnderecoDTO> listEnderecoDTO = enderecoService.findByEndereco();
        return listEnderecoDTO;
    }
}
