package com.squadra.bootcamp.igormendes.desafiofinal.exceptions;

public class CampoNullException extends NullPointerException{

}
