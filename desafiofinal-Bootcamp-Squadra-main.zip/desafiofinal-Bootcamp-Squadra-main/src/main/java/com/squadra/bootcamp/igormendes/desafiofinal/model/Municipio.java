package com.squadra.bootcamp.igormendes.desafiofinal.model;

import lombok.Data;

import java.util.List;

import javax.persistence.*;
import javax.validation.constraints.NotNull;

import com.fasterxml.jackson.annotation.JsonBackReference;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonManagedReference;


@Data
@Entity
@Table(name = "tb_municipio")
public class Municipio{
    @Id
    @GeneratedValue(generator = "municipio_sequence" ,strategy = GenerationType.SEQUENCE)
    @SequenceGenerator(name= "municipio_sequence" , sequenceName = "muni_seq")
    @Column(name = "CODIGO_MUNICIPIO")
    private Long codigoMunicipio;
    @ManyToOne
    @JoinColumn(name = "CODIGO_UF")
    private Uf codigoUF;
    @JsonManagedReference
    @JsonIgnore
    @OneToMany(cascade = CascadeType.ALL)
    private List<Uf>uf;
    @Column(name = "NOME",unique = true)
    private String nome;
    @Column(name = "STATUS")
    private Integer status;
    public Municipio(){

    }


}   
