package com.squadra.bootcamp.igormendes.desafiofinal.exceptions;

import lombok.Data;

import java.util.List;

import org.springframework.http.HttpStatus;

@Data
public class ErrorResponse {
   
    private  String message;
    private  int code;
    private  HttpStatus status;
    private  String objectName;
    private  List<ErrorObject> errors;
    public ErrorResponse(String message, HttpStatus status, String objectName) {
    }
    public ErrorResponse(String string, int value, String reasonPhrase, String objectName2, List<ErrorObject> errors2) {
    }
}
